# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Proyecto.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(400, 355)
        self.HostL = QLabel(Form)
        self.HostL.setObjectName(u"HostL")
        self.HostL.setGeometry(QRect(10, 10, 31, 16))
        self.line_2 = QFrame(Form)
        self.line_2.setObjectName(u"line_2")
        self.line_2.setGeometry(QRect(-10, 240, 431, 16))
        self.line_2.setFrameShape(QFrame.HLine)
        self.line_2.setFrameShadow(QFrame.Sunken)
        self.PortL = QLabel(Form)
        self.PortL.setObjectName(u"PortL")
        self.PortL.setGeometry(QRect(10, 40, 55, 16))
        self.HostLE = QLineEdit(Form)
        self.HostLE.setObjectName(u"HostLE")
        self.HostLE.setGeometry(QRect(40, 10, 161, 22))
        self.PortLE = QLineEdit(Form)
        self.PortLE.setObjectName(u"PortLE")
        self.PortLE.setGeometry(QRect(40, 40, 161, 22))
        self.PortLE.setEchoMode(QLineEdit.Normal)
        self.gridLayoutWidget_2 = QWidget(Form)
        self.gridLayoutWidget_2.setObjectName(u"gridLayoutWidget_2")
        self.gridLayoutWidget_2.setGeometry(QRect(10, 260, 381, 80))
        self.gridLayout_2 = QGridLayout(self.gridLayoutWidget_2)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.gridLayout_2.setContentsMargins(0, 0, 0, 0)
        self.ExaminarPB = QPushButton(self.gridLayoutWidget_2)
        self.ExaminarPB.setObjectName(u"ExaminarPB")

        self.gridLayout_2.addWidget(self.ExaminarPB, 0, 2, 1, 1)

        self.ArchivoLE = QLineEdit(self.gridLayoutWidget_2)
        self.ArchivoLE.setObjectName(u"ArchivoLE")

        self.gridLayout_2.addWidget(self.ArchivoLE, 0, 1, 1, 1)

        self.ArchivoL = QLabel(self.gridLayoutWidget_2)
        self.ArchivoL.setObjectName(u"ArchivoL")

        self.gridLayout_2.addWidget(self.ArchivoL, 0, 0, 1, 1)

        self.EnviarPB_file = QPushButton(self.gridLayoutWidget_2)
        self.EnviarPB_file.setObjectName(u"EnviarPB_file")

        self.gridLayout_2.addWidget(self.EnviarPB_file, 1, 0, 1, 3)

        self.gridLayoutWidget = QWidget(Form)
        self.gridLayoutWidget.setObjectName(u"gridLayoutWidget")
        self.gridLayoutWidget.setGeometry(QRect(10, 90, 381, 141))
        self.gridLayout = QGridLayout(self.gridLayoutWidget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.CorreoL = QLabel(self.gridLayoutWidget)
        self.CorreoL.setObjectName(u"CorreoL")

        self.gridLayout.addWidget(self.CorreoL, 2, 0, 1, 1)

        self.ContrasenaL = QLabel(self.gridLayoutWidget)
        self.ContrasenaL.setObjectName(u"ContrasenaL")

        self.gridLayout.addWidget(self.ContrasenaL, 3, 0, 1, 1)

        self.NombreL = QLabel(self.gridLayoutWidget)
        self.NombreL.setObjectName(u"NombreL")

        self.gridLayout.addWidget(self.NombreL, 1, 0, 1, 1)

        self.NombreLE = QLineEdit(self.gridLayoutWidget)
        self.NombreLE.setObjectName(u"NombreLE")

        self.gridLayout.addWidget(self.NombreLE, 1, 1, 1, 1)

        self.ContraLE = QLineEdit(self.gridLayoutWidget)
        self.ContraLE.setObjectName(u"ContraLE")
        self.ContraLE.setEchoMode(QLineEdit.Password)

        self.gridLayout.addWidget(self.ContraLE, 3, 1, 1, 1)

        self.CorreoLE = QLineEdit(self.gridLayoutWidget)
        self.CorreoLE.setObjectName(u"CorreoLE")

        self.gridLayout.addWidget(self.CorreoLE, 2, 1, 1, 1)

        self.EnviarPB = QPushButton(self.gridLayoutWidget)
        self.EnviarPB.setObjectName(u"EnviarPB")

        self.gridLayout.addWidget(self.EnviarPB, 4, 0, 1, 2)

        self.line = QFrame(Form)
        self.line.setObjectName(u"line")
        self.line.setGeometry(QRect(-10, 70, 431, 16))
        self.line.setFrameShape(QFrame.HLine)
        self.line.setFrameShadow(QFrame.Sunken)
        self.ConectarPB = QPushButton(Form)
        self.ConectarPB.setObjectName(u"ConectarPB")
        self.ConectarPB.setGeometry(QRect(270, 20, 93, 28))

        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Proyecto", None))
        self.HostL.setText(QCoreApplication.translate("Form", u"Host", None))
        self.PortL.setText(QCoreApplication.translate("Form", u"Port", None))
        self.ExaminarPB.setText(QCoreApplication.translate("Form", u"Examinar", None))
        self.ArchivoL.setText(QCoreApplication.translate("Form", u"Archivo", None))
        self.EnviarPB_file.setText(QCoreApplication.translate("Form", u"Enviar archivo", None))
        self.CorreoL.setText(QCoreApplication.translate("Form", u"Correo", None))
        self.ContrasenaL.setText(QCoreApplication.translate("Form", u"Contrase\u00f1a", None))
        self.NombreL.setText(QCoreApplication.translate("Form", u"Nombre", None))
        self.EnviarPB.setText(QCoreApplication.translate("Form", u"Enviar", None))
        self.ConectarPB.setText(QCoreApplication.translate("Form", u"Conectar", None))
    # retranslateUi

