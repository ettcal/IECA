from PySide2.QtUiTools import QUiLoader     #Esta se agregó
from PySide2.QtCore import QFile    #Esta se agregó
from PySide2 import QtGui
from PySide2.QtWidgets import QApplication, QFileDialog, QMainWindow
import sys
from Proyecto import *
import socket
import pickle
from estudiante import Estudiante

class Proyecto(QMainWindow):
    def __init__(self):
        super(Proyecto, self).__init__()
        self.ui = QUiLoader().load(QFile("Proyecto.ui"))

#----------------Conectar & deconectar--------
        self.ui.ConectarPB.clicked.connect(self.conectar)
# ----------------Alumno---------------------
        self.ui.EnviarPB.clicked.connect(self.enviarEstudiante)
# ----------------Archivo---------------------
        self.ui.ExaminarPB.clicked.connect(self.examinar)
        self.ui.EnviarPB_file.clicked.connect(self.enviarArchivo)

    #Slot

# ----------------Conectar & deconectar--------
    def conectar(self):
        self.s = socket.socket()
        host = self.ui.HostLE.text()
        port = int(self.ui.PortLE.text())
        self.s.connect((host, port))

        self.ui.HostLE.setReadOnly(True)
        self.ui.PortLE.setReadOnly(True)

# ----------------Alumno---------------------
    def enviarEstudiante(self):
        estudiante = Estudiante(self.ui.NombreLE.text(), self.ui.CorreoLE.text(), self.ui.ContraLE.text())
        estudiante_seriado = pickle.dumps(estudiante)
        self.s.send(estudiante_seriado)
        res = self.s.recv(1024)
        print(f'Respuesta: \n\t{res.decode()}')
        #self.s.close()

# ----------------Archivo---------------------
    def examinar(self):
        file, _ = QFileDialog.getOpenFileName(filter='*.zip')
        self.ui.ArchivoLE.setText(file)

    def enviarArchivo(self):
        file = open(self.ui.ArchivoLE.text(), "rb")
        file_serializado = pickle.dumps(file.read())

        if isinstance(file,Estudiante):
            self.s.send(file_serializado)
            res = self.s.recv(1024)
            print(res.decode())

        else:
            self.s.send(b'INI')
            res = self.s.recv(1024)
            print(res.decode())

            if len(file_serializado) < 1024:
                self.s.send(file_serializado)
                res = self.s.recv(1024)
                print(res.decode())
            else:
                continuar = True
                index = 0
                while continuar:
                    chunk = file_serializado[index:index + 1024]
                    if not chunk:
                        continuar = False
                        continue
                    self.s.send(chunk)
                    res = self.s.recv(1024)
                    print(f'Respuesta: \n\t{res.decode()}')
                    index = index + 1024

            self.s.send(b'FIN')
            res = self.s.recv(1024)
            print(res.decode())

        self.s.close()



if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = Proyecto()
    window.ui.show()
    sys.exit(app.exec_())